const funmenu = (prefix) => { 
	return `
╭┈─────𝙵𝙸𝚃𝚄𝚁 𝙽𝚈𝙰 𝙺𝙰𝙺
╰─❁۪۪
╰─➤ *${prefix}tebakgambar*
╰─➤ *${prefix}caklontong*
╰─➤ *${prefix}family100*
╰─➤ *${prefix}game*
╰─➤ *${prefix}truth*
╰─➤ *${prefix}dare*
╰─➤ *${prefix}quotes*
╰─➤ *${prefix}hilih*
╰─➤ *${prefix}alay* [text]
╰─➤ *${prefix}simi* [text]
╰─➤ *${prefix}bucin*
╰─➤ *${prefix}gtts* [text]
╰─➤ *${prefix}tts*
╭┈─────ABBAS OFFICIAL 
╰─❁۪۪`
}
exports.funmenu = funmenu